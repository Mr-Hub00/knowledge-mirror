document.addEventListener('DOMContentLoaded', () => {
  const hour = new Date().getHours();
  if (hour >= 6 && hour < 18) {
    document.body.classList.add('day');
  } else {
    document.body.classList.remove('day');
  }
});
